DRIVER_PATH = r"C:\SeleniumDrivers"             ## Web Driver Path
BOOKING_URL = r"https://www.booking.com"        ## Website Landing Page
IMPLICIT_WAIT = 15                            ## Wait until these seconds for rendering
CURRENCY_TYPE = r"INR"
OUT_FILE      = r"C:\TEST\Hotel_Deals.csv"
RUPEE_SYMBOL  = '\u20b9'

